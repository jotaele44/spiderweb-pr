import { adjudicateSourceCoverage, classifyBboxApplicability, classifyGridBinding, declareSourceCoverage, evaluateAoiApplicability, freezeAoi, reconcileSourceCoverage } from "./spatialAoiCoverage";
const sha = "a".repeat(64);
const polygon = { id: "AOI-1", geometry: { type: "Polygon", coordinates: [[[-66.2, 18.2], [-66.0, 18.2], [-66.0, 18.4], [-66.2, 18.4], [-66.2, 18.2]]] }, properties: { name: "bounded" } };

describe("Spiderweb frozen AOI", () => {
  it("freezes polygon AOI with source manifestation and deterministic bounds", () => {
    const aoi = freezeAoi({ features: [polygon], sourceManifestationSha256: sha });
    expect(aoi.sourceManifestationSha256).toBe(sha);
    expect(aoi.bbox).toEqual([-66.2, 18.2, -66, 18.4]);
    expect(aoi.geometryAuthority).toBe("ANALYSIS_INPUT");
  });
  it("excludes non-AOI geometries without converting them into boundaries", () => {
    const aoi = freezeAoi({ features: [polygon, { id: "P", geometry: { type: "Point", coordinates: [-66.1, 18.3] } }], sourceManifestationSha256: sha });
    expect(aoi.features.length).toBe(1);
    expect(aoi.excluded[0].reason).toBe("NON_AOI_GEOMETRY:Point");
  });
  it("fails closed when no Polygon or MultiPolygon remains", () => {
    expect(() => freezeAoi({ features: [{ id: "P", geometry: { type: "Point", coordinates: [-66, 18] } }], sourceManifestationSha256: sha })).toThrow();
  });
  it("requires a frozen source SHA-256 instead of a filename-only AOI identity", () => {
    expect(() => freezeAoi({ features: [polygon], sourceManifestationSha256: "not-a-hash" })).toThrow();
  });
});

describe("Spiderweb AOI applicability", () => {
  it("classifies fully within", () => expect(classifyBboxApplicability([-66.2,18.2,-66,18.4], [-67,17,-65,19])).toBe("FULLY_WITHIN"));
  it("classifies partial overlap", () => expect(classifyBboxApplicability([-66.2,18.2,-66,18.4], [-66.1,18,-65.9,19])).toBe("PARTIAL"));
  it("classifies touch-only without promoting it to overlap", () => expect(classifyBboxApplicability([-66.2,18.2,-66,18.4], [-66,18,-65.5,19])).toBe("TOUCH_ONLY"));
  it("classifies outside and explicit null/empty separately", () => {
    expect(classifyBboxApplicability([-66.2,18.2,-66,18.4], [-65,17,-64,19])).toBe("OUTSIDE");
    expect(classifyBboxApplicability([-66.2,18.2,-66,18.4], null)).toBe("NULL_EMPTY");
  });
  it("keeps malformed bounds unresolved", () => expect(classifyBboxApplicability([-66.2,18.2,-66,18.4], [-65,19,-66,17])).toBe("UNRESOLVED"));
  it("closes a declared 30-source applicability denominator without hardcoding provider identity", () => {
    const aoi = freezeAoi({ features: [polygon], sourceManifestationSha256: sha });
    const receipt = evaluateAoiApplicability(aoi, Array.from({ length: 30 }, (_, index) => ({ sourceId: `S${index + 1}`, footprint: [-67, 17, -65, 19] as [number,number,number,number] })));
    expect(receipt.arithmetic).toEqual({ total: 30, closed: true });
    expect(receipt.counts.FULLY_WITHIN).toBe(30);
    expect(receipt.unresolved).toBe(0);
  });
});

describe("Spiderweb source coverage ledger", () => {
  it("requires evidence for AVAILABLE and NO_DATA terminal states", () => {
    const ledger = declareSourceCoverage(["A"]);
    expect(() => adjudicateSourceCoverage(ledger, "A", "AVAILABLE")).toThrow();
    expect(() => adjudicateSourceCoverage(ledger, "A", "NO_DATA")).toThrow();
  });
  it("treats documented NO_DATA as terminal negative evidence", () => {
    const ledger = adjudicateSourceCoverage(declareSourceCoverage(["A"]), "A", "NO_DATA", { evidenceRef: "receipt:no-data" });
    const result = reconcileSourceCoverage(ledger);
    expect(result.state).toBe("COMPLETE");
    expect(result.arithmetic.noData).toBe(1);
  });
  it("keeps blocked or failed sources as material residue", () => {
    let ledger = declareSourceCoverage(["A", "B"]);
    ledger = adjudicateSourceCoverage(ledger, "A", "AVAILABLE", { evidenceRef: "sha256:a" });
    ledger = adjudicateSourceCoverage(ledger, "B", "BLOCKED", { residue: "provider unavailable" });
    const result = reconcileSourceCoverage(ledger);
    expect(result.state).toBe("BLOCKED");
    expect(result.zeroMaterialResidue).toBeFalse();
  });
  it("closes positive and negative universes with zero unexplained residue", () => {
    let ledger = declareSourceCoverage(["A", "B", "C"]);
    ledger = adjudicateSourceCoverage(ledger, "A", "AVAILABLE", { evidenceRef: "sha256:a" });
    ledger = adjudicateSourceCoverage(ledger, "B", "NO_DATA", { evidenceRef: "receipt:b-zero" });
    ledger = adjudicateSourceCoverage(ledger, "C", "AVAILABLE", { evidenceRef: "sha256:c" });
    const result = reconcileSourceCoverage(ledger);
    expect(result.state).toBe("COMPLETE");
    expect(result.arithmetic.closed).toBeTrue();
  });
});

describe("Spiderweb legacy grid identity", () => {
  it("does not convert cell-set membership into cell identity", () => {
    expect(classifyGridBinding({ cellId: null, cellSet: ["393", "394"], transformVerified: false })).toEqual({ state: "CANDIDATE_NOT_IDENTITY", identity: null, candidates: ["393", "394"] });
  });
  it("requires explicit verified transform for exact cell identity", () => {
    expect(classifyGridBinding({ cellId: "393", cellSet: ["393"], transformVerified: false }).state).toBe("CANDIDATE_NOT_IDENTITY");
    expect(classifyGridBinding({ cellId: "393", cellSet: ["393"], transformVerified: true })).toEqual({ state: "VERIFIED", identity: "393", candidates: ["393"] });
  });
  it("keeps absent cell evidence unresolved", () => expect(classifyGridBinding({ cellId: null, cellSet: [], transformVerified: false }).state).toBe("UNRESOLVED"));
});
