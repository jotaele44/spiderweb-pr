export type Bbox = [number, number, number, number];
export type Applicability = "FULLY_WITHIN" | "PARTIAL" | "TOUCH_ONLY" | "OUTSIDE" | "NULL_EMPTY" | "UNRESOLVED";
export type CoverageState = "PENDING" | "AVAILABLE" | "NO_DATA" | "BLOCKED" | "FAILED" | "UNRESOLVED";

export type AoiFeature = {
  id?: string | number | null;
  geometry?: { type?: string | null; coordinates?: unknown } | null;
  properties?: Record<string, unknown> | null;
};

export type FrozenAoi = {
  schema: "spiderweb-frozen-aoi/v1";
  aoiId: string;
  sourceManifestationSha256: string;
  crs: string;
  geometryAuthority: "ANALYSIS_INPUT";
  features: Array<{ stableId: string; geometry: NonNullable<AoiFeature["geometry"]>; properties: Record<string, unknown> }>;
  bbox: Bbox;
  excluded: Array<{ index: number; reason: string }>;
};

const SHA256_RE = /^[a-f0-9]{64}$/;

function walkCoordinates(value: unknown, points: Array<[number, number]>) {
  if (!Array.isArray(value)) return;
  if (value.length >= 2 && typeof value[0] === "number" && typeof value[1] === "number") {
    if (Number.isFinite(value[0]) && Number.isFinite(value[1])) points.push([value[0], value[1]]);
    return;
  }
  value.forEach((item) => walkCoordinates(item, points));
}

function boundsForFeatures(features: FrozenAoi["features"]): Bbox {
  const points: Array<[number, number]> = [];
  features.forEach((feature) => walkCoordinates(feature.geometry.coordinates, points));
  if (!points.length) throw new Error("AOI has no finite coordinates");
  const xs = points.map((point) => point[0]);
  const ys = points.map((point) => point[1]);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}

function stableToken(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

export function freezeAoi(input: { features: AoiFeature[]; sourceManifestationSha256: string; crs?: string | null }): FrozenAoi {
  const sha = input.sourceManifestationSha256.trim().toLowerCase();
  if (!SHA256_RE.test(sha)) throw new Error("valid source manifestation SHA-256 is required");
  const excluded: FrozenAoi["excluded"] = [];
  const features = input.features.flatMap((feature, index) => {
    const type = feature.geometry?.type ?? "";
    if (type !== "Polygon" && type !== "MultiPolygon") {
      excluded.push({ index, reason: feature.geometry ? `NON_AOI_GEOMETRY:${type || "UNKNOWN"}` : "NULL_EMPTY_GEOMETRY" });
      return [];
    }
    const stableId = feature.id === undefined || feature.id === null || String(feature.id) === "" ? `aoi-feature-${index + 1}` : String(feature.id);
    return [{ stableId, geometry: feature.geometry!, properties: { ...(feature.properties ?? {}) } }];
  });
  if (!features.length) throw new Error("AOI requires at least one Polygon or MultiPolygon feature");
  const bbox = boundsForFeatures(features);
  const crs = input.crs?.trim() || "EPSG:4326";
  return {
    schema: "spiderweb-frozen-aoi/v1",
    aoiId: `aoi:${stableToken(`${sha}:${crs}:${JSON.stringify(bbox)}:${features.map((feature) => feature.stableId).sort().join("|")}`)}`,
    sourceManifestationSha256: sha,
    crs,
    geometryAuthority: "ANALYSIS_INPUT",
    features,
    bbox,
    excluded,
  };
}

function validBbox(value: Bbox | null | undefined): value is Bbox {
  return Boolean(value && value.length === 4 && value.every(Number.isFinite) && value[0] <= value[2] && value[1] <= value[3]);
}

export function classifyBboxApplicability(aoi: Bbox | null | undefined, footprint: Bbox | null | undefined): Applicability {
  if (!validBbox(aoi)) return "UNRESOLVED";
  if (footprint === null) return "NULL_EMPTY";
  if (!validBbox(footprint)) return "UNRESOLVED";
  const ix0 = Math.max(aoi[0], footprint[0]);
  const iy0 = Math.max(aoi[1], footprint[1]);
  const ix1 = Math.min(aoi[2], footprint[2]);
  const iy1 = Math.min(aoi[3], footprint[3]);
  if (ix0 > ix1 || iy0 > iy1) return "OUTSIDE";
  if (ix0 === ix1 || iy0 === iy1) return "TOUCH_ONLY";
  const fullyWithin = aoi[0] >= footprint[0] && aoi[1] >= footprint[1] && aoi[2] <= footprint[2] && aoi[3] <= footprint[3];
  return fullyWithin ? "FULLY_WITHIN" : "PARTIAL";
}

export function evaluateAoiApplicability(aoi: FrozenAoi, sources: Array<{ sourceId: string; footprint: Bbox | null | undefined }>) {
  const rows = sources.map((source) => ({ sourceId: source.sourceId, state: classifyBboxApplicability(aoi.bbox, source.footprint) }));
  const counts = Object.fromEntries((["FULLY_WITHIN", "PARTIAL", "TOUCH_ONLY", "OUTSIDE", "NULL_EMPTY", "UNRESOLVED"] as Applicability[]).map((state) => [state, rows.filter((row) => row.state === state).length])) as Record<Applicability, number>;
  const total = rows.length;
  const closed = Object.values(counts).reduce((sum, value) => sum + value, 0) === total;
  return { schema: "spiderweb-aoi-applicability/v1" as const, aoiId: aoi.aoiId, rows, counts, arithmetic: { total, closed }, unresolved: counts.UNRESOLVED };
}

export type CoverageLedger = {
  schema: "spiderweb-source-coverage-ledger/v1";
  rows: Array<{ sourceId: string; state: CoverageState; evidenceRef: string | null; residue: string | null }>;
};

export function declareSourceCoverage(sourceIds: string[]): CoverageLedger {
  const normalized = sourceIds.map((value) => value.trim());
  if (normalized.some((value) => !value)) throw new Error("sourceId is required");
  if (new Set(normalized).size !== normalized.length) throw new Error("duplicate sourceId");
  return { schema: "spiderweb-source-coverage-ledger/v1", rows: normalized.map((sourceId) => ({ sourceId, state: "PENDING", evidenceRef: null, residue: null })) };
}

export function adjudicateSourceCoverage(ledger: CoverageLedger, sourceId: string, state: Exclude<CoverageState, "PENDING">, options: { evidenceRef?: string | null; residue?: string | null } = {}): CoverageLedger {
  if (!ledger.rows.some((row) => row.sourceId === sourceId)) throw new Error("unknown sourceId");
  if ((state === "AVAILABLE" || state === "NO_DATA") && !options.evidenceRef?.trim()) throw new Error("terminal positive/negative coverage requires evidenceRef");
  return {
    ...ledger,
    rows: ledger.rows.map((row) => row.sourceId === sourceId ? { sourceId, state, evidenceRef: options.evidenceRef?.trim() || null, residue: options.residue?.trim() || null } : row),
  };
}

export function reconcileSourceCoverage(ledger: CoverageLedger) {
  const count = (state: CoverageState) => ledger.rows.filter((row) => row.state === state).length;
  const arithmetic = {
    total: ledger.rows.length,
    available: count("AVAILABLE"),
    noData: count("NO_DATA"),
    blocked: count("BLOCKED"),
    failed: count("FAILED"),
    unresolved: count("UNRESOLVED"),
    pending: count("PENDING"),
  };
  const closed = arithmetic.available + arithmetic.noData + arithmetic.blocked + arithmetic.failed + arithmetic.unresolved + arithmetic.pending === arithmetic.total;
  const zeroMaterialResidue = arithmetic.blocked === 0 && arithmetic.failed === 0 && arithmetic.unresolved === 0 && arithmetic.pending === 0;
  return { schema: "spiderweb-source-coverage-receipt/v1" as const, arithmetic: { ...arithmetic, closed }, state: closed && zeroMaterialResidue ? "COMPLETE" as const : (arithmetic.blocked || arithmetic.failed || arithmetic.unresolved ? "BLOCKED" as const : "OPEN" as const), zeroMaterialResidue };
}

export function classifyGridBinding(input: { cellId: string | null; cellSet: string[]; transformVerified: boolean }) {
  if (input.cellId && input.transformVerified) return { state: "VERIFIED" as const, identity: input.cellId, candidates: [input.cellId] };
  if (input.cellSet.length) return { state: "CANDIDATE_NOT_IDENTITY" as const, identity: null, candidates: [...new Set(input.cellSet)].sort() };
  return { state: "UNRESOLVED" as const, identity: null, candidates: [] as string[] };
}
