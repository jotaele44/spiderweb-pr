import {
  buildAnalysisReceipt,
  buildUploadManifest,
  classifySpatialFile,
  createSpatialDataset,
  preflightSpatialAnalysis,
  presetEligibility,
} from "./spatialUploadPipeline";

const sha = (char: string) => char.repeat(64);
const feature = (id: string | null, type = "Point", properties: Record<string, unknown> = {}) => ({ id, geometry: type ? { type } : null, properties });

describe("Spiderweb upload manifest", () => {
  it("classifies supported and blocked file families without pretending unsupported parsers exist", () => {
    expect(classifySpatialFile("a.geojson")).toBe("GEOJSON");
    expect(classifySpatialFile("a.kml")).toBe("KML");
    expect(classifySpatialFile("a.gpkg")).toBe("GEOPACKAGE");
    expect(classifySpatialFile("a.kmz")).toBe("KMZ");
    expect(classifySpatialFile("a.tif")).toBe("RASTER");
    expect(classifySpatialFile("a.exe")).toBe("UNKNOWN");
  });

  it("keeps source identity separate from runtime file identity, including duplicate manifestations", () => {
    const manifest = buildUploadManifest([
      { name: "a.geojson", size: 10, sha256: sha("a") },
      { name: "copy.geojson", size: 10, sha256: sha("a") },
    ]);
    expect(manifest.entries[0].runtimeFileId).not.toBe(manifest.entries[1].runtimeFileId);
    expect(manifest.entries[0].sourceId).not.toBe(manifest.entries[1].sourceId);
    expect(manifest.entries[0].sourceId.startsWith(`source:${sha("a")}`)).toBeTrue();
    expect(manifest.arithmetic.closed).toBeTrue();
  });

  it("groups only authoritatively related shapefile sidecars by basename", () => {
    const manifest = buildUploadManifest([
      { name: "roads.shp", size: 1 },
      { name: "roads.dbf", size: 1 },
      { name: "roads.shx", size: 1 },
      { name: "other.prj", size: 1 },
      { name: "notes.csv", size: 1 },
    ]);
    expect(manifest.groups.length).toBe(2);
    expect(manifest.groups.find((group) => group.groupKey === "shapefile:roads")?.complete).toBeTrue();
    expect(manifest.groups.find((group) => group.groupKey === "shapefile:other")?.missingRequired).toEqual(["shp", "dbf", "shx"]);
    expect(manifest.arithmetic.groupedManifestations).toBe(4);
    expect(manifest.arithmetic.independentManifestations).toBe(1);
  });

  it("does not merge unrelated archive/container inputs", () => {
    const manifest = buildUploadManifest([
      { name: "one.zip", size: 1 },
      { name: "one.kmz", size: 1 },
      { name: "one.gpkg", size: 1 },
    ]);
    expect(manifest.groups).toEqual([]);
    expect(manifest.entries.map((entry) => entry.groupKey)).toEqual([null, null, null]);
  });
});

describe("Spiderweb typed datasets and presets", () => {
  it("keeps RAW/NORMALIZED/CANONICAL state explicit", () => {
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const raw = createSpatialDataset({ datasetId: "D1", entries: manifest.entries, state: "RAW", features: [feature("1")] });
    const normalized = createSpatialDataset({ datasetId: "D2", entries: manifest.entries, state: "NORMALIZED", features: [feature("1")] });
    const canonical = createSpatialDataset({ datasetId: "D3", entries: manifest.entries, state: "CANONICAL", features: [feature("1")] });
    expect([raw.state, normalized.state, canonical.state]).toEqual(["RAW", "NORMALIZED", "CANONICAL"]);
  });

  it("blocks GeoPackage until a genuine runtime parser exists", () => {
    const manifest = buildUploadManifest([{ name: "a.gpkg", size: 100 }]);
    const dataset = createSpatialDataset({ datasetId: "GPKG", entries: manifest.entries });
    expect(dataset.adapterState).toBe("BLOCKED");
    expect(dataset.warnings).toContain("GEOPACKAGE_UNSUPPORTED_RUNTIME");
  });

  it("requires a specialized parser for complete or partial shapefile groups", () => {
    const complete = buildUploadManifest([{ name: "roads.shp", size: 1 }, { name: "roads.dbf", size: 1 }, { name: "roads.shx", size: 1 }]);
    const partial = buildUploadManifest([{ name: "buildings.shp", size: 1 }, { name: "buildings.dbf", size: 1 }]);
    expect(createSpatialDataset({ datasetId: "S1", entries: complete.entries }).adapterState).toBe("PARSER_REQUIRED");
    expect(partial.groups[0].complete).toBeFalse();
    expect(partial.groups[0].missingRequired).toEqual(["shx"]);
  });

  it("calculates exact-difference eligibility from actual dataset capabilities", () => {
    const leftManifest = buildUploadManifest([{ name: "left.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const rightManifest = buildUploadManifest([{ name: "right.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const left = createSpatialDataset({ datasetId: "L", entries: leftManifest.entries, role: "PRIMARY", features: [feature("1"), feature("2")] });
    const right = createSpatialDataset({ datasetId: "R", entries: rightManifest.entries, role: "COMPARISON", features: [feature("1"), feature("2")] });
    expect(presetEligibility("EXACT_DIFFERENCE", [left, right])).toEqual({ presetId: "EXACT_DIFFERENCE", eligible: true, reasons: [] });
  });

  it("fails exact-difference eligibility on mixed CRS instead of silently transforming", () => {
    const a = buildUploadManifest([{ name: "a.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const b = buildUploadManifest([{ name: "b.geojson", size: 1, declaredCrs: "EPSG:32161" }]);
    const left = createSpatialDataset({ datasetId: "L", entries: a.entries, features: [feature("1")] });
    const right = createSpatialDataset({ datasetId: "R", entries: b.entries, features: [feature("1")] });
    const result = presetEligibility("EXACT_DIFFERENCE", [left, right]);
    expect(result.eligible).toBeFalse();
    expect(result.reasons).toContain("MIXED_CRS");
  });

  it("does not enable terrain presets without raster or explicit elevation capability", () => {
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const plain = createSpatialDataset({ datasetId: "D", entries: manifest.entries, features: [feature("1", "Point", { name: "x" })] });
    const elevated = createSpatialDataset({ datasetId: "E", entries: manifest.entries, features: [feature("1", "Point", { elevation: 12 })] });
    expect(presetEligibility("TERRAIN", [plain]).eligible).toBeFalse();
    expect(presetEligibility("TERRAIN", [elevated]).eligible).toBeTrue();
  });
});

describe("Spiderweb analysis preflight and receipt", () => {
  it("fails closed on duplicate feature IDs and unsupported geometry", () => {
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const dataset = createSpatialDataset({ datasetId: "D", entries: manifest.entries, features: [feature("same"), feature("same", "GeometryCollection")] });
    const preflight = preflightSpatialAnalysis("INSPECT", [dataset]);
    expect(preflight.state).toBe("BLOCKED");
    expect(preflight.errors).toContain("D:DUPLICATE_FEATURE_IDS");
    expect(preflight.errors).toContain("D:UNSUPPORTED_GEOMETRY:1");
  });

  it("reports null/unidentified features without promoting them to identity", () => {
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const dataset = createSpatialDataset({ datasetId: "D", entries: manifest.entries, features: [feature(null, ""), feature("2")] });
    const preflight = preflightSpatialAnalysis("INSPECT", [dataset]);
    expect(preflight.warnings).toContain("D:UNIDENTIFIED_FEATURES");
    expect(preflight.warnings).toContain("D:NULL_GEOMETRY:1");
  });

  it("fails on duplicate runtime IDs and duplicate manifestation binding", () => {
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const left = createSpatialDataset({ datasetId: "DUP", entries: manifest.entries, features: [feature("1")] });
    const right = createSpatialDataset({ datasetId: "DUP", entries: manifest.entries, features: [feature("2")] });
    const preflight = preflightSpatialAnalysis("EXACT_DIFFERENCE", [left, right]);
    expect(preflight.errors).toContain("DUPLICATE_RUNTIME_DATASET_ID");
    expect(preflight.errors).toContain("DUPLICATE_MANIFESTATION_BINDING");
  });

  it("blocks heterogeneous batches rather than inventing a parser", () => {
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1 }, { name: "b.csv", size: 1 }]);
    const dataset = createSpatialDataset({ datasetId: "MIXED", entries: manifest.entries, features: [] });
    expect(dataset.kind).toBe("UNKNOWN");
    expect(dataset.adapterState).toBe("BLOCKED");
    expect(preflightSpatialAnalysis("INSPECT", [dataset]).errors).toContain("ADAPTER_NOT_READY");
  });

  it("produces deterministic receipts with closed file/manifest/feature arithmetic", () => {
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1, sha256: sha("b"), declaredCrs: "EPSG:4326" }]);
    const dataset = createSpatialDataset({ datasetId: "D", entries: manifest.entries, role: "PRIMARY", state: "NORMALIZED", features: [feature("1"), feature("2")], acceptedFeatures: 2, rejectedFeatures: 1 });
    const preflight = preflightSpatialAnalysis("INSPECT", [dataset]);
    const first = buildAnalysisReceipt({ presetId: "INSPECT", manifest, datasets: [dataset], preflight });
    const second = buildAnalysisReceipt({ presetId: "INSPECT", manifest, datasets: [dataset], preflight });
    expect(first.deterministicId).toBe(second.deterministicId);
    expect(first.arithmetic).toEqual({ inputFiles: 1, sourceManifestations: 1, datasets: 1, acceptedFeatures: 2, rejectedFeatures: 1, totalFeaturesConsidered: 3, sourceClosure: true });
  });
});
