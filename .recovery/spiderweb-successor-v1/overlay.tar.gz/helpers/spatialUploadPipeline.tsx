export type SpatialFileKind =
  | "GEOJSON"
  | "JSON"
  | "KML"
  | "CSV"
  | "SHAPEFILE_PART"
  | "KMZ"
  | "GEOPACKAGE"
  | "ARCHIVE"
  | "RASTER"
  | "UNKNOWN";

export type SpatialDatasetState = "RAW" | "NORMALIZED" | "CANONICAL";
export type DatasetRole = "PRIMARY" | "COMPARISON" | "TERRAIN" | "CONTEXT";
export type AdapterState = "READY" | "PARSER_REQUIRED" | "BLOCKED";

export type UploadFileDescriptor = {
  name: string;
  size: number;
  sha256?: string | null;
  mediaType?: string | null;
  declaredCrs?: string | null;
};

export type UploadManifestEntry = {
  manifestationId: string;
  sourceId: string;
  runtimeFileId: string;
  name: string;
  basename: string;
  extension: string;
  size: number;
  sha256: string | null;
  mediaType: string | null;
  declaredCrs: string | null;
  kind: SpatialFileKind;
  groupKey: string | null;
};

export type UploadManifest = {
  schema: "spiderweb-upload-manifest/v1";
  entries: UploadManifestEntry[];
  groups: Array<{
    groupKey: string;
    kind: "SHAPEFILE";
    manifestationIds: string[];
    complete: boolean;
    missingRequired: string[];
  }>;
  arithmetic: {
    inputFiles: number;
    sourceManifestations: number;
    groupedManifestations: number;
    independentManifestations: number;
    closed: boolean;
  };
};

export type FeatureLike = {
  id?: string | number | null;
  geometry?: { type?: string | null } | null;
  properties?: Record<string, unknown> | null;
};

export type SpatialDataset = {
  schema: "spiderweb-spatial-dataset/v1";
  datasetId: string;
  sourceIds: string[];
  manifestationIds: string[];
  state: SpatialDatasetState;
  role: DatasetRole;
  kind: SpatialFileKind | "SHAPEFILE";
  adapterState: AdapterState;
  crs: string | null;
  features: FeatureLike[];
  acceptedFeatures: number;
  rejectedFeatures: number;
  capabilities: {
    vector: boolean;
    raster: boolean;
    exactFeatureIds: boolean;
    geometryTypes: string[];
    attributes: boolean;
    temporal: boolean;
    elevation: boolean;
  };
  warnings: string[];
};

export type AnalysisPresetId = "INSPECT" | "EXACT_DIFFERENCE" | "TOPOLOGY" | "TERRAIN" | "TEMPORAL";

export const SPATIAL_ANALYSIS_PRESETS = [
  { id: "INSPECT", minDatasets: 1, maxDatasets: 1, requiresVector: true, requiresExactIds: false, requiresSameCrs: false, requiresElevation: false },
  { id: "EXACT_DIFFERENCE", minDatasets: 2, maxDatasets: 2, requiresVector: true, requiresExactIds: true, requiresSameCrs: true, requiresElevation: false },
  { id: "TOPOLOGY", minDatasets: 1, maxDatasets: 1, requiresVector: true, requiresExactIds: false, requiresSameCrs: false, requiresElevation: false },
  { id: "TERRAIN", minDatasets: 1, maxDatasets: 2, requiresVector: false, requiresExactIds: false, requiresSameCrs: false, requiresElevation: true },
  { id: "TEMPORAL", minDatasets: 2, maxDatasets: 2, requiresVector: true, requiresExactIds: true, requiresSameCrs: true, requiresElevation: false },
] as const;

const SHAPEFILE_REQUIRED = ["shp", "dbf", "shx"] as const;
const SHAPEFILE_PARTS = new Set(["shp", "dbf", "shx", "prj", "cpg", "sbn", "sbx"]);
const SUPPORTED_GEOMETRIES = new Set(["Point", "LineString", "Polygon", "MultiPoint", "MultiLineString", "MultiPolygon"]);

function extensionOf(name: string): string {
  const clean = name.trim().toLowerCase();
  const index = clean.lastIndexOf(".");
  return index < 0 ? "" : clean.slice(index + 1);
}

function basenameOf(name: string): string {
  const trimmed = name.trim();
  const slash = Math.max(trimmed.lastIndexOf("/"), trimmed.lastIndexOf("\\"));
  const file = slash >= 0 ? trimmed.slice(slash + 1) : trimmed;
  const dot = file.lastIndexOf(".");
  return (dot > 0 ? file.slice(0, dot) : file).toLowerCase();
}

export function classifySpatialFile(name: string): SpatialFileKind {
  const ext = extensionOf(name);
  if (ext === "geojson") return "GEOJSON";
  if (ext === "json") return "JSON";
  if (ext === "kml") return "KML";
  if (ext === "csv") return "CSV";
  if (SHAPEFILE_PARTS.has(ext)) return "SHAPEFILE_PART";
  if (ext === "kmz") return "KMZ";
  if (ext === "gpkg") return "GEOPACKAGE";
  if (ext === "zip" || ext === "7z" || ext === "tar" || ext === "gz") return "ARCHIVE";
  if (ext === "tif" || ext === "tiff" || ext === "asc" || ext === "img") return "RASTER";
  return "UNKNOWN";
}

function normalizedSha(value?: string | null): string | null {
  const sha = value?.trim().toLowerCase() ?? "";
  return /^[a-f0-9]{64}$/.test(sha) ? sha : null;
}

function stableToken(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

export function buildUploadManifest(files: UploadFileDescriptor[]): UploadManifest {
  const seenSourceTokens = new Map<string, number>();
  const entries = files.map((file, index): UploadManifestEntry => {
    const sha256 = normalizedSha(file.sha256);
    const basename = basenameOf(file.name);
    const extension = extensionOf(file.name);
    const kind = classifySpatialFile(file.name);
    const sourceToken = sha256 ?? stableToken(`${file.name}\u0000${file.size}\u0000${file.mediaType ?? ""}`);
    const occurrence = seenSourceTokens.get(sourceToken) ?? 0;
    seenSourceTokens.set(sourceToken, occurrence + 1);
    const sourceId = `source:${sourceToken}${occurrence ? `:${occurrence + 1}` : ""}`;
    return {
      manifestationId: `manifestation:${index + 1}:${stableToken(`${sourceId}\u0000${file.name}\u0000${file.size}`)}`,
      sourceId,
      runtimeFileId: `upload:${index + 1}`,
      name: file.name,
      basename,
      extension,
      size: Number.isFinite(file.size) && file.size >= 0 ? file.size : 0,
      sha256,
      mediaType: file.mediaType ?? null,
      declaredCrs: file.declaredCrs?.trim() || null,
      kind,
      groupKey: kind === "SHAPEFILE_PART" ? `shapefile:${basename}` : null,
    };
  });

  const shapefileGroups = new Map<string, UploadManifestEntry[]>();
  entries.filter((entry) => entry.kind === "SHAPEFILE_PART").forEach((entry) => {
    const group = shapefileGroups.get(entry.groupKey!) ?? [];
    group.push(entry);
    shapefileGroups.set(entry.groupKey!, group);
  });

  const groups = [...shapefileGroups.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([groupKey, members]) => {
    const extSet = new Set(members.map((member) => member.extension));
    const missingRequired = SHAPEFILE_REQUIRED.filter((required) => !extSet.has(required));
    return {
      groupKey,
      kind: "SHAPEFILE" as const,
      manifestationIds: members.map((member) => member.manifestationId).sort(),
      complete: missingRequired.length === 0,
      missingRequired: [...missingRequired],
    };
  });

  const groupedManifestations = groups.reduce((total, group) => total + group.manifestationIds.length, 0);
  const independentManifestations = entries.length - groupedManifestations;
  return {
    schema: "spiderweb-upload-manifest/v1",
    entries,
    groups,
    arithmetic: {
      inputFiles: files.length,
      sourceManifestations: entries.length,
      groupedManifestations,
      independentManifestations,
      closed: files.length === entries.length && groupedManifestations + independentManifestations === entries.length,
    },
  };
}

function datasetCapabilities(features: FeatureLike[], kind: SpatialDataset["kind"]) {
  const geometryTypes = [...new Set(features.map((feature) => feature.geometry?.type ?? "NULL"))].sort();
  const ids = features.map((feature) => feature.id === undefined || feature.id === null ? "" : String(feature.id));
  const nonEmptyIds = ids.filter(Boolean);
  const exactFeatureIds = nonEmptyIds.length === features.length && new Set(nonEmptyIds).size === features.length;
  const attributes = features.some((feature) => feature.properties && Object.keys(feature.properties).length > 0);
  const elevation = features.some((feature) => {
    const props = feature.properties ?? {};
    return ["elevation", "elev", "depth", "z"].some((key) => typeof props[key] === "number");
  });
  return {
    vector: !["RASTER", "ARCHIVE", "KMZ", "GEOPACKAGE", "UNKNOWN"].includes(kind),
    raster: kind === "RASTER",
    exactFeatureIds,
    geometryTypes,
    attributes,
    temporal: features.some((feature) => {
      const props = feature.properties ?? {};
      return ["date", "datetime", "timestamp", "observed_at", "observedAt"].some((key) => props[key] !== undefined && props[key] !== null);
    }),
    elevation,
  };
}

export function createSpatialDataset(input: {
  datasetId: string;
  entries: UploadManifestEntry[];
  role?: DatasetRole;
  state?: SpatialDatasetState;
  features?: FeatureLike[];
  acceptedFeatures?: number;
  rejectedFeatures?: number;
}): SpatialDataset {
  if (!input.datasetId.trim()) throw new Error("datasetId is required");
  if (input.entries.length === 0) throw new Error("at least one source manifestation is required");
  const kinds = [...new Set(input.entries.map((entry) => entry.kind))];
  const shapefileOnly = kinds.every((kind) => kind === "SHAPEFILE_PART");
  const kind: SpatialDataset["kind"] = shapefileOnly ? "SHAPEFILE" : kinds.length === 1 ? kinds[0] : "UNKNOWN";
  const features = input.features ?? [];
  const warnings: string[] = [];
  let adapterState: AdapterState = "READY";
  if (kind === "GEOPACKAGE") { adapterState = "BLOCKED"; warnings.push("GEOPACKAGE_UNSUPPORTED_RUNTIME"); }
  else if (["KMZ", "ARCHIVE", "RASTER", "SHAPEFILE"].includes(kind)) { adapterState = "PARSER_REQUIRED"; warnings.push(`${kind}_ADAPTER_REQUIRED`); }
  else if (kind === "UNKNOWN") { adapterState = "BLOCKED"; warnings.push("HETEROGENEOUS_OR_UNKNOWN_DATASET"); }
  const crsValues = [...new Set(input.entries.map((entry) => entry.declaredCrs).filter((value): value is string => Boolean(value)))];
  if (crsValues.length > 1) warnings.push("MIXED_DECLARED_CRS_WITHIN_DATASET");
  return {
    schema: "spiderweb-spatial-dataset/v1",
    datasetId: input.datasetId,
    sourceIds: [...new Set(input.entries.map((entry) => entry.sourceId))].sort(),
    manifestationIds: input.entries.map((entry) => entry.manifestationId).sort(),
    state: input.state ?? "RAW",
    role: input.role ?? "CONTEXT",
    kind,
    adapterState,
    crs: crsValues.length === 1 ? crsValues[0] : null,
    features,
    acceptedFeatures: input.acceptedFeatures ?? features.length,
    rejectedFeatures: input.rejectedFeatures ?? 0,
    capabilities: datasetCapabilities(features, kind),
    warnings,
  };
}

export function presetEligibility(presetId: AnalysisPresetId, datasets: SpatialDataset[]) {
  const preset = SPATIAL_ANALYSIS_PRESETS.find((candidate) => candidate.id === presetId)!;
  const reasons: string[] = [];
  if (datasets.length < preset.minDatasets) reasons.push("TOO_FEW_DATASETS");
  if (datasets.length > preset.maxDatasets) reasons.push("TOO_MANY_DATASETS");
  if (datasets.some((dataset) => dataset.adapterState !== "READY")) reasons.push("ADAPTER_NOT_READY");
  if (preset.requiresVector && datasets.some((dataset) => !dataset.capabilities.vector)) reasons.push("VECTOR_REQUIRED");
  if (preset.requiresExactIds && datasets.some((dataset) => !dataset.capabilities.exactFeatureIds)) reasons.push("EXACT_FEATURE_IDS_REQUIRED");
  if (preset.requiresElevation && datasets.every((dataset) => !dataset.capabilities.elevation && !dataset.capabilities.raster)) reasons.push("ELEVATION_OR_RASTER_REQUIRED");
  if (preset.requiresSameCrs) {
    const crs = datasets.map((dataset) => dataset.crs).filter((value): value is string => Boolean(value));
    if (crs.length !== datasets.length) reasons.push("CRS_REQUIRED");
    else if (new Set(crs).size > 1) reasons.push("MIXED_CRS");
  }
  return { presetId, eligible: reasons.length === 0, reasons: [...new Set(reasons)].sort() };
}

export function preflightSpatialAnalysis(presetId: AnalysisPresetId, datasets: SpatialDataset[]) {
  const eligibility = presetEligibility(presetId, datasets);
  const errors = [...eligibility.reasons];
  const warnings: string[] = [];
  const datasetIds = datasets.map((dataset) => dataset.datasetId);
  if (new Set(datasetIds).size !== datasetIds.length) errors.push("DUPLICATE_RUNTIME_DATASET_ID");
  const manifestationIds = datasets.flatMap((dataset) => dataset.manifestationIds);
  if (new Set(manifestationIds).size !== manifestationIds.length) errors.push("DUPLICATE_MANIFESTATION_BINDING");
  datasets.forEach((dataset) => {
    const featureIds = dataset.features.map((feature) => feature.id === undefined || feature.id === null ? "" : String(feature.id));
    const nonEmpty = featureIds.filter(Boolean);
    if (nonEmpty.length !== featureIds.length) warnings.push(`${dataset.datasetId}:UNIDENTIFIED_FEATURES`);
    if (new Set(nonEmpty).size !== nonEmpty.length) errors.push(`${dataset.datasetId}:DUPLICATE_FEATURE_IDS`);
    const unsupported = dataset.features.filter((feature) => feature.geometry?.type && !SUPPORTED_GEOMETRIES.has(String(feature.geometry.type))).length;
    const nullGeometry = dataset.features.filter((feature) => !feature.geometry || !feature.geometry.type).length;
    if (unsupported) errors.push(`${dataset.datasetId}:UNSUPPORTED_GEOMETRY:${unsupported}`);
    if (nullGeometry) warnings.push(`${dataset.datasetId}:NULL_GEOMETRY:${nullGeometry}`);
    dataset.warnings.forEach((warning) => warnings.push(`${dataset.datasetId}:${warning}`));
  });
  return {
    schema: "spiderweb-analysis-preflight/v1" as const,
    presetId,
    state: errors.length ? "BLOCKED" as const : "PASS" as const,
    errors: [...new Set(errors)].sort(),
    warnings: [...new Set(warnings)].sort(),
  };
}

function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableJson(item)}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

export function buildAnalysisReceipt(input: {
  presetId: AnalysisPresetId;
  manifest: UploadManifest;
  datasets: SpatialDataset[];
  preflight: ReturnType<typeof preflightSpatialAnalysis>;
}) {
  const acceptedFeatures = input.datasets.reduce((total, dataset) => total + dataset.acceptedFeatures, 0);
  const rejectedFeatures = input.datasets.reduce((total, dataset) => total + dataset.rejectedFeatures, 0);
  const payload = {
    schema: "spiderweb-analysis-receipt/v1" as const,
    presetId: input.presetId,
    manifestationIds: input.manifest.entries.map((entry) => entry.manifestationId).sort(),
    sourceIds: input.manifest.entries.map((entry) => entry.sourceId).sort(),
    datasetIds: input.datasets.map((dataset) => dataset.datasetId).sort(),
    states: input.datasets.map((dataset) => ({ datasetId: dataset.datasetId, state: dataset.state, role: dataset.role })).sort((a, b) => a.datasetId.localeCompare(b.datasetId)),
    preflightState: input.preflight.state,
    errors: [...input.preflight.errors].sort(),
    warnings: [...input.preflight.warnings].sort(),
    arithmetic: {
      inputFiles: input.manifest.arithmetic.inputFiles,
      sourceManifestations: input.manifest.arithmetic.sourceManifestations,
      datasets: input.datasets.length,
      acceptedFeatures,
      rejectedFeatures,
      totalFeaturesConsidered: acceptedFeatures + rejectedFeatures,
      sourceClosure: input.manifest.arithmetic.closed,
    },
  };
  const canonical = stableJson(payload);
  return { ...payload, deterministicId: `receipt:${stableToken(canonical)}` };
}
