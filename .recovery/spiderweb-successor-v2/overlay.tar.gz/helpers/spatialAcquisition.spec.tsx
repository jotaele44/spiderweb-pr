import { applyFetchGate, createAcquisitionRun, nextPendingAcquisitionUnit, reconcileAcquisitionRun, recordAcquisitionAttempt } from "./spatialAcquisition";

const unit = (id: string) => ({ sourceUnitId: id, url: `https://example.test/${id}.geojson`, query: { bbox: "-67,17,-65,19", page: 1 }, expectedFormat: "GEOJSON" as const });
const sha = (char: string) => char.repeat(64);

function enabledRun(ids = ["A"]) {
  return applyFetchGate(createAcquisitionRun(ids.map(unit), "2026-10-04T20:00:00.000Z"), { manifestFrozen: true, policyAllowsFetch: true });
}

function success(run: ReturnType<typeof enabledRun>, id: string, char = "a") {
  return recordAcquisitionAttempt(run, { sourceUnitId: id, retrievedAt: "2026-10-04T20:01:00.000Z", responseStatus: 200, headers: { ETag: "x", "Content-Type": "application/geo+json" }, rawSha256: sha(char), byteLength: 42, formatValidated: true, geometryValidated: true });
}

describe("Spiderweb acquisition run contract", () => {
  it("fails closed with fetch disabled by default", () => {
    const run = createAcquisitionRun([unit("A")]);
    expect(run.fetchEnabled).toBeFalse();
    const attempted = recordAcquisitionAttempt(run, { sourceUnitId: "A", retrievedAt: "2026-10-04T20:01:00.000Z", responseStatus: 200, rawSha256: sha("a"), byteLength: 1, formatValidated: true });
    expect(attempted.attempts[0].state).toBe("BLOCKED");
    expect(attempted.attempts[0].residue).toContain("FETCH_DISABLED");
  });

  it("requires both frozen manifest and policy authorization before enabling fetch", () => {
    const run = createAcquisitionRun([unit("A")]);
    expect(applyFetchGate(run, { manifestFrozen: true, policyAllowsFetch: false }).fetchEnabled).toBeFalse();
    expect(applyFetchGate(run, { manifestFrozen: false, policyAllowsFetch: true }).fetchEnabled).toBeFalse();
    expect(applyFetchGate(run, { manifestFrozen: true, policyAllowsFetch: true }).fetchEnabled).toBeTrue();
  });

  it("rejects duplicate source-unit identities before execution", () => {
    expect(() => createAcquisitionRun([unit("A"), unit("A")])).toThrow();
  });

  it("rejects empty bytes and missing raw SHA-256", () => {
    const run = enabledRun();
    const out = recordAcquisitionAttempt(run, { sourceUnitId: "A", retrievedAt: "2026-10-04T20:01:00.000Z", responseStatus: 200, byteLength: 0, formatValidated: true });
    expect(out.attempts[0].state).toBe("BLOCKED");
    expect(out.attempts[0].residue).toContain("EMPTY_OR_INVALID_BYTES");
    expect(out.attempts[0].residue).toContain("RAW_SHA256_REQUIRED");
  });

  it("enforces format validation before geometry validation", () => {
    const run = enabledRun();
    const out = recordAcquisitionAttempt(run, { sourceUnitId: "A", retrievedAt: "2026-10-04T20:01:00.000Z", responseStatus: 200, rawSha256: sha("b"), byteLength: 5, formatValidated: false, geometryValidated: true });
    expect(out.attempts[0].residue).toContain("GEOMETRY_BEFORE_FORMAT");
    expect(out.attempts[0].state).toBe("BLOCKED");
  });

  it("freezes URL query retrieval UTC headers bytes and SHA-256 on success", () => {
    const out = success(enabledRun(), "A");
    const attempt = out.attempts[0];
    expect(attempt.state).toBe("PASS");
    expect(attempt.headers["content-type"]).toBe("application/geo+json");
    expect(attempt.headers.etag).toBe("x");
    expect(attempt.query).toEqual({ bbox: "-67,17,-65,19", page: 1 });
    expect(attempt.rawSha256).toBe(sha("a"));
  });

  it("is restartable and skips already successful source units", () => {
    const run = success(enabledRun(["A", "B"]), "A");
    expect(nextPendingAcquisitionUnit(run)?.sourceUnitId).toBe("B");
    const rerun = success(run, "A", "c");
    expect(rerun.attempts.filter((attempt) => attempt.sourceUnitId === "A").length).toBe(1);
  });

  it("does not certify partial acquisition as complete", () => {
    const run = success(enabledRun(["A", "B"]), "A");
    const receipt = reconcileAcquisitionRun(run);
    expect(receipt.state).toBe("OPEN");
    expect(receipt.arithmetic).toEqual({ total: 2, pass: 1, blocked: 0, failed: 0, pending: 1, closed: true });
  });

  it("closes acquisition arithmetic only when every declared unit passes", () => {
    let run = success(enabledRun(["A", "B"]), "A");
    run = success(run, "B", "d");
    const receipt = reconcileAcquisitionRun(run);
    expect(receipt.state).toBe("COMPLETE");
    expect(receipt.arithmetic).toEqual({ total: 2, pass: 2, blocked: 0, failed: 0, pending: 0, closed: true });
    expect(receipt.manifestations.length).toBe(2);
  });
});
