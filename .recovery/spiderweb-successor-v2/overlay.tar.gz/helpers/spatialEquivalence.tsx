export type ComparableFeature = {
  id?: string | number | null;
  geometry?: unknown;
  properties?: Record<string, unknown> | null;
};
export type ComparableCollection = {
  source: "ARCHIVE" | "WFS";
  crs: string | null;
  features: ComparableFeature[];
};
export type EquivalenceDisposition = "EXACT_MATCH" | "GEOMETRY_MISMATCH" | "ATTRIBUTE_MISMATCH" | "MISSING_ARCHIVE" | "MISSING_WFS" | "UNRESOLVED";

function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableJson(item)}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function indexFeatures(features: ComparableFeature[]) {
  const map = new Map<string, ComparableFeature>();
  const duplicates = new Set<string>();
  let unidentified = 0;
  features.forEach((feature) => {
    const id = feature.id === undefined || feature.id === null ? "" : String(feature.id);
    if (!id) { unidentified += 1; return; }
    if (map.has(id)) duplicates.add(id); else map.set(id, feature);
  });
  return { map, duplicates: [...duplicates].sort(), unidentified };
}

function propertySchema(feature: ComparableFeature): string[] {
  return Object.keys(feature.properties ?? {}).sort();
}

export function compareArchiveToWfs(archive: ComparableCollection, wfs: ComparableCollection) {
  const a = indexFeatures(archive.features);
  const b = indexFeatures(wfs.features);
  const ids = [...new Set([...a.map.keys(), ...b.map.keys()])].sort();
  const rows = ids.map((id) => {
    const left = a.map.get(id), right = b.map.get(id);
    if (!left) return { stableId: id, disposition: "MISSING_ARCHIVE" as EquivalenceDisposition, schemaEqual: false, geometryEqual: false, attributesEqual: false };
    if (!right) return { stableId: id, disposition: "MISSING_WFS" as EquivalenceDisposition, schemaEqual: false, geometryEqual: false, attributesEqual: false };
    const schemaEqual = stableJson(propertySchema(left)) === stableJson(propertySchema(right));
    const geometryEqual = left.geometry !== null && left.geometry !== undefined && right.geometry !== null && right.geometry !== undefined && stableJson(left.geometry) === stableJson(right.geometry);
    const attributesEqual = stableJson(left.properties ?? {}) === stableJson(right.properties ?? {});
    let disposition: EquivalenceDisposition = "EXACT_MATCH";
    if (!geometryEqual) disposition = "GEOMETRY_MISMATCH";
    else if (!schemaEqual || !attributesEqual) disposition = "ATTRIBUTE_MISMATCH";
    return { stableId: id, disposition, schemaEqual, geometryEqual, attributesEqual };
  });
  const exact = rows.filter((row) => row.disposition === "EXACT_MATCH").length;
  const mismatch = rows.filter((row) => row.disposition === "GEOMETRY_MISMATCH" || row.disposition === "ATTRIBUTE_MISMATCH").length;
  const missingArchive = rows.filter((row) => row.disposition === "MISSING_ARCHIVE").length;
  const missingWfs = rows.filter((row) => row.disposition === "MISSING_WFS").length;
  const duplicateIds = [...new Set([...a.duplicates, ...b.duplicates])].sort();
  const unresolved = a.unidentified + b.unidentified + duplicateIds.length + (archive.crs && wfs.crs && archive.crs !== wfs.crs ? 1 : 0);
  const totalCandidates = rows.length;
  const arithmeticClosed = exact + mismatch + missingArchive + missingWfs === totalCandidates;
  const certified = arithmeticClosed && unresolved === 0 && mismatch === 0 && missingArchive === 0 && missingWfs === 0 && totalCandidates > 0 && archive.crs === wfs.crs;
  return {
    schema: "spiderweb-archive-wfs-equivalence/v1" as const,
    identityBasis: "EXACT_STABLE_ID" as const,
    nameMatching: "DENY" as const,
    nearestMatching: "DENY" as const,
    archiveCrs: archive.crs,
    wfsCrs: wfs.crs,
    rows,
    duplicateIds,
    unidentified: { archive: a.unidentified, wfs: b.unidentified },
    arithmetic: { totalCandidates, exact, mismatch, missingArchive, missingWfs, unresolved, closed: arithmeticClosed },
    certified,
  };
}
