import { compareArchiveToWfs } from "./spatialEquivalence";

const point = (id: string | null, x: number, properties: Record<string, unknown> = { name: "A" }) => ({ id, geometry: { type: "Point", coordinates: [x, 18] }, properties });
const collection = (source: "ARCHIVE" | "WFS", features: any[], crs: string | null = "EPSG:4326") => ({ source, features, crs });

describe("Spiderweb archive to WFS equivalence", () => {
  it("certifies exact stable-ID geometry/schema/attribute equality regardless of feature order", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point("A", -66), point("B", -65)]), collection("WFS", [point("B", -65), point("A", -66)]));
    expect(out.certified).toBeTrue();
    expect(out.arithmetic.exact).toBe(2);
  });

  it("does not treat equal counts as equivalence when geometry differs", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point("A", -66)]), collection("WFS", [point("A", -65)]));
    expect(out.certified).toBeFalse();
    expect(out.rows[0].disposition).toBe("GEOMETRY_MISMATCH");
  });

  it("never pairs equal names when stable IDs differ", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point("ARCHIVE-ID", -66, { name: "Same" })]), collection("WFS", [point("WFS-ID", -66, { name: "Same" })]));
    expect(out.certified).toBeFalse();
    expect(out.arithmetic.missingArchive).toBe(1);
    expect(out.arithmetic.missingWfs).toBe(1);
    expect(out.nameMatching).toBe("DENY");
  });

  it("blocks duplicate stable IDs as unresolved identity residue", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point("A", -66), point("A", -66)]), collection("WFS", [point("A", -66)]));
    expect(out.certified).toBeFalse();
    expect(out.duplicateIds).toEqual(["A"]);
    expect(out.arithmetic.unresolved).toBeGreaterThan(0);
  });

  it("preserves missing stable IDs as unresolved instead of inventing identity", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point(null, -66), point("A", -66)]), collection("WFS", [point("A", -66)]));
    expect(out.certified).toBeFalse();
    expect(out.unidentified.archive).toBe(1);
  });

  it("fails on attribute/schema drift even when geometry and stable ID match", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point("A", -66, { name: "A", class: 1 })]), collection("WFS", [point("A", -66, { name: "A", class: 2, extra: true })]));
    expect(out.certified).toBeFalse();
    expect(out.rows[0].disposition).toBe("ATTRIBUTE_MISMATCH");
    expect(out.rows[0].schemaEqual).toBeFalse();
  });

  it("fails closed on CRS mismatch without silently transforming", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point("A", -66)], "EPSG:4326"), collection("WFS", [point("A", -66)], "EPSG:32161"));
    expect(out.certified).toBeFalse();
    expect(out.arithmetic.unresolved).toBe(1);
  });

  it("treats null geometry as geometry residue", () => {
    const archive = collection("ARCHIVE", [{ id: "A", geometry: null, properties: { name: "A" } }]);
    const wfs = collection("WFS", [point("A", -66)]);
    const out = compareArchiveToWfs(archive, wfs);
    expect(out.certified).toBeFalse();
    expect(out.rows[0].disposition).toBe("GEOMETRY_MISMATCH");
  });

  it("closes candidate arithmetic while certification remains false on any residue", () => {
    const out = compareArchiveToWfs(collection("ARCHIVE", [point("A", -66), point("B", -65)]), collection("WFS", [point("A", -66), point("C", -64)]));
    expect(out.arithmetic.closed).toBeTrue();
    expect(out.arithmetic.totalCandidates).toBe(3);
    expect(out.arithmetic.exact + out.arithmetic.mismatch + out.arithmetic.missingArchive + out.arithmetic.missingWfs).toBe(3);
    expect(out.certified).toBeFalse();
  });
});
