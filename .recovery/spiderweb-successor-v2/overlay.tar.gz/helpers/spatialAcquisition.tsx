export type AcquisitionFormat = "GEOJSON" | "JSON" | "KML" | "CSV" | "BINARY";
export type AcquisitionUnit = {
  sourceUnitId: string;
  url: string;
  query?: Record<string, string | number | boolean | null>;
  expectedFormat: AcquisitionFormat;
};
export type AcquisitionAttemptState = "PASS" | "BLOCKED" | "FAILED";
export type AcquisitionAttempt = {
  sourceUnitId: string;
  url: string;
  query: Record<string, string | number | boolean | null>;
  retrievedAt: string;
  responseStatus: number;
  headers: Record<string, string>;
  rawSha256: string | null;
  byteLength: number;
  expectedFormat: AcquisitionFormat;
  formatValidated: boolean;
  geometryValidated: boolean;
  state: AcquisitionAttemptState;
  residue: string[];
};
export type AcquisitionRun = {
  schema: "spiderweb-acquisition-run/v1";
  runId: string;
  createdAt: string;
  manifestFrozen: boolean;
  policyAllowsFetch: boolean;
  fetchEnabled: boolean;
  units: AcquisitionUnit[];
  attempts: AcquisitionAttempt[];
};

const SHA256_RE = /^[a-f0-9]{64}$/;

function stableToken(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableJson(item)}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function normalizeHeaders(headers?: Record<string, string | number | null>): Record<string, string> {
  return Object.fromEntries(Object.entries(headers ?? {}).map(([key, value]) => [key.trim().toLowerCase(), String(value ?? "")]).sort(([a], [b]) => a.localeCompare(b)));
}

function normalizeQuery(query?: AcquisitionUnit["query"]): Record<string, string | number | boolean | null> {
  return Object.fromEntries(Object.entries(query ?? {}).sort(([a], [b]) => a.localeCompare(b)));
}

export function createAcquisitionRun(units: AcquisitionUnit[], createdAt = "1970-01-01T00:00:00.000Z"): AcquisitionRun {
  const ids = units.map((unit) => unit.sourceUnitId.trim());
  if (ids.some((id) => !id)) throw new Error("sourceUnitId is required");
  if (new Set(ids).size !== ids.length) throw new Error("duplicate sourceUnitId");
  const normalizedUnits = units.map((unit) => ({ ...unit, sourceUnitId: unit.sourceUnitId.trim(), query: normalizeQuery(unit.query) }));
  return {
    schema: "spiderweb-acquisition-run/v1",
    runId: `acq:${stableToken(stableJson(normalizedUnits))}`,
    createdAt,
    manifestFrozen: false,
    policyAllowsFetch: false,
    fetchEnabled: false,
    units: normalizedUnits,
    attempts: [],
  };
}

export function applyFetchGate(run: AcquisitionRun, gate: { manifestFrozen: boolean; policyAllowsFetch: boolean }): AcquisitionRun {
  return {
    ...run,
    manifestFrozen: gate.manifestFrozen,
    policyAllowsFetch: gate.policyAllowsFetch,
    fetchEnabled: gate.manifestFrozen && gate.policyAllowsFetch,
  };
}

export function nextPendingAcquisitionUnit(run: AcquisitionRun): AcquisitionUnit | null {
  const terminal = new Set(run.attempts.filter((attempt) => attempt.state === "PASS").map((attempt) => attempt.sourceUnitId));
  return run.units.find((unit) => !terminal.has(unit.sourceUnitId)) ?? null;
}

export function recordAcquisitionAttempt(run: AcquisitionRun, input: {
  sourceUnitId: string;
  retrievedAt: string;
  responseStatus: number;
  headers?: Record<string, string | number | null>;
  rawSha256?: string | null;
  byteLength: number;
  formatValidated: boolean;
  geometryValidated?: boolean;
}): AcquisitionRun {
  const unit = run.units.find((candidate) => candidate.sourceUnitId === input.sourceUnitId);
  if (!unit) throw new Error("unknown sourceUnitId");
  const residue: string[] = [];
  if (!run.fetchEnabled) residue.push("FETCH_DISABLED");
  if (!/^https:\/\//i.test(unit.url)) residue.push("INSECURE_SOURCE_URL");
  if (!Number.isFinite(input.byteLength) || input.byteLength <= 0) residue.push("EMPTY_OR_INVALID_BYTES");
  const rawSha256 = input.rawSha256?.trim().toLowerCase() ?? null;
  if (!rawSha256 || !SHA256_RE.test(rawSha256)) residue.push("RAW_SHA256_REQUIRED");
  if (!Number.isInteger(input.responseStatus) || input.responseStatus < 200 || input.responseStatus >= 300) residue.push("HTTP_STATUS_NOT_SUCCESS");
  if (!/Z$/.test(input.retrievedAt) || Number.isNaN(Date.parse(input.retrievedAt))) residue.push("RETRIEVAL_UTC_REQUIRED");
  if (input.geometryValidated && !input.formatValidated) residue.push("GEOMETRY_BEFORE_FORMAT");
  if (!input.formatValidated) residue.push("FORMAT_NOT_VALIDATED");
  const state: AcquisitionAttemptState = residue.length ? "BLOCKED" : "PASS";
  const attempt: AcquisitionAttempt = {
    sourceUnitId: unit.sourceUnitId,
    url: unit.url,
    query: normalizeQuery(unit.query),
    retrievedAt: input.retrievedAt,
    responseStatus: input.responseStatus,
    headers: normalizeHeaders(input.headers),
    rawSha256,
    byteLength: Number.isFinite(input.byteLength) && input.byteLength > 0 ? input.byteLength : 0,
    expectedFormat: unit.expectedFormat,
    formatValidated: input.formatValidated,
    geometryValidated: Boolean(input.geometryValidated),
    state,
    residue: [...new Set(residue)].sort(),
  };
  return { ...run, attempts: [...run.attempts.filter((existing) => existing.sourceUnitId !== input.sourceUnitId), attempt].sort((a, b) => a.sourceUnitId.localeCompare(b.sourceUnitId)) };
}

export function reconcileAcquisitionRun(run: AcquisitionRun) {
  const attemptsById = new Map(run.attempts.map((attempt) => [attempt.sourceUnitId, attempt]));
  let pass = 0, blocked = 0, failed = 0, pending = 0;
  run.units.forEach((unit) => {
    const attempt = attemptsById.get(unit.sourceUnitId);
    if (!attempt) pending += 1;
    else if (attempt.state === "PASS") pass += 1;
    else if (attempt.state === "FAILED") failed += 1;
    else blocked += 1;
  });
  const total = run.units.length;
  const closed = pass + blocked + failed + pending === total;
  const state = closed && total > 0 && pass === total ? "COMPLETE" : (blocked || failed ? "BLOCKED" : "OPEN");
  return {
    schema: "spiderweb-acquisition-receipt/v1" as const,
    runId: run.runId,
    state,
    arithmetic: { total, pass, blocked, failed, pending, closed },
    manifestations: run.attempts.filter((attempt) => attempt.state === "PASS").map((attempt) => ({
      sourceUnitId: attempt.sourceUnitId,
      url: attempt.url,
      query: attempt.query,
      retrievedAt: attempt.retrievedAt,
      headers: attempt.headers,
      rawSha256: attempt.rawSha256,
      byteLength: attempt.byteLength,
      format: attempt.expectedFormat,
    })).sort((a, b) => a.sourceUnitId.localeCompare(b.sourceUnitId)),
  };
}
