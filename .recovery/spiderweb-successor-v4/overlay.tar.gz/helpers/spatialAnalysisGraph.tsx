import { analyzeSpatialCollection, compareSpatialCollections } from "./spatialLayerAnalysis";
import { deriveTerrainCandidates, validateTopology } from "./spatialFrontendTools";
import { buildAnalysisReceipt, preflightSpatialAnalysis, type AnalysisPresetId, type SpatialDataset, type UploadManifest } from "./spatialUploadPipeline";

type GraphInput = {
  presetId: AnalysisPresetId;
  manifest: UploadManifest;
  datasets: SpatialDataset[];
  temporal?: { leftDate?: string | null; rightDate?: string | null };
};

type ToolCollection = { type: "FeatureCollection"; features: any[] };
const asCollection = (dataset: SpatialDataset): ToolCollection => ({ type: "FeatureCollection", features: dataset.features as any[] });

export function executeSpatialAnalysisGraph(input: GraphInput) {
  const preflight = preflightSpatialAnalysis(input.presetId, input.datasets);
  if (preflight.state !== "PASS") {
    return {
      schema: "spiderweb-analysis-graph-result/v1" as const,
      presetId: input.presetId,
      state: "BLOCKED" as const,
      preflight,
      output: null,
      receipt: buildAnalysisReceipt({ presetId: input.presetId, manifest: input.manifest, datasets: input.datasets, preflight }),
    };
  }

  let output: unknown;
  if (input.presetId === "INSPECT") {
    output = analyzeSpatialCollection(asCollection(input.datasets[0]));
  } else if (input.presetId === "EXACT_DIFFERENCE") {
    output = compareSpatialCollections(asCollection(input.datasets[0]), asCollection(input.datasets[1]));
  } else if (input.presetId === "TOPOLOGY") {
    output = validateTopology(asCollection(input.datasets[0]));
  } else if (input.presetId === "TERRAIN") {
    output = input.datasets.flatMap((dataset) => deriveTerrainCandidates(asCollection(dataset)));
  } else {
    output = {
      contract: "spiderweb-temporal-difference/v1" as const,
      leftDate: input.temporal?.leftDate ?? null,
      rightDate: input.temporal?.rightDate ?? null,
      difference: compareSpatialCollections(asCollection(input.datasets[0]), asCollection(input.datasets[1])),
      interpretation: "MANIFESTATION_LEVEL_CHANGE_NOT_CAUSATION" as const,
    };
  }

  return {
    schema: "spiderweb-analysis-graph-result/v1" as const,
    presetId: input.presetId,
    state: "PASS" as const,
    preflight,
    output,
    receipt: buildAnalysisReceipt({ presetId: input.presetId, manifest: input.manifest, datasets: input.datasets, preflight }),
  };
}
