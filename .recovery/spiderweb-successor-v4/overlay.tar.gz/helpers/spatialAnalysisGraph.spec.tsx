import { executeSpatialAnalysisGraph } from "./spatialAnalysisGraph";
import { buildUploadManifest, createSpatialDataset } from "./spatialUploadPipeline";

const feature = (id: string, x: number, properties: Record<string, unknown> = {}) => ({ id, geometry: { type: "Point", coordinates: [x, 18] }, properties });
const dataset = (id: string, name: string, features: any[], role: "PRIMARY" | "COMPARISON" | "TERRAIN" | "CONTEXT" = "PRIMARY", crs = "EPSG:4326") => {
  const manifest = buildUploadManifest([{ name, size: 1, declaredCrs: crs }]);
  return { manifest, value: createSpatialDataset({ datasetId: id, entries: manifest.entries, role, features }) };
};

describe("Spiderweb canonical analysis graph", () => {
  it("blocks execution when preflight fails instead of bypassing the graph", () => {
    const a = dataset("A", "a.geojson", [feature("dup", -66), feature("dup", -65)]);
    const out = executeSpatialAnalysisGraph({ presetId: "INSPECT", manifest: a.manifest, datasets: [a.value] });
    expect(out.state).toBe("BLOCKED");
    expect(out.output).toBeNull();
  });

  it("executes INSPECT through the shared graph", () => {
    const a = dataset("A", "a.geojson", [feature("1", -66), feature("2", -65)]);
    const out: any = executeSpatialAnalysisGraph({ presetId: "INSPECT", manifest: a.manifest, datasets: [a.value] });
    expect(out.state).toBe("PASS");
    expect(out.output.featureCount).toBe(2);
  });

  it("executes exact-ID difference without name or nearest matching", () => {
    const a = dataset("A", "a.geojson", [feature("1", -66), feature("2", -65)]);
    const b = dataset("B", "b.geojson", [feature("1", -66), feature("3", -64)], "COMPARISON");
    const manifest = buildUploadManifest([...a.manifest.entries.map((entry) => ({ name: entry.name, size: entry.size, declaredCrs: entry.declaredCrs })), ...b.manifest.entries.map((entry) => ({ name: entry.name, size: entry.size, declaredCrs: entry.declaredCrs }))]);
    const out: any = executeSpatialAnalysisGraph({ presetId: "EXACT_DIFFERENCE", manifest, datasets: [a.value, b.value] });
    expect(out.output.identityBasis).toBe("EXACT_FEATURE_ID");
    expect(out.output.leftOnly).toEqual(["2"]);
    expect(out.output.rightOnly).toEqual(["3"]);
  });

  it("executes topology validation through the shared graph", () => {
    const a = dataset("A", "a.geojson", [feature("1", -66)]);
    const out: any = executeSpatialAnalysisGraph({ presetId: "TOPOLOGY", manifest: a.manifest, datasets: [a.value] });
    expect(out.output.contract).toBe("spiderweb-topology-ledger/v1");
    expect(out.output.state).toBe("PASS");
  });

  it("executes terrain candidates only from explicit elevation/depth properties", () => {
    const a = dataset("A", "a.geojson", [feature("1", -66, { elevation: 12 }), feature("2", -65, { name: "no elevation" })], "TERRAIN");
    const out: any = executeSpatialAnalysisGraph({ presetId: "TERRAIN", manifest: a.manifest, datasets: [a.value] });
    expect(out.output.length).toBe(1);
    expect(out.output[0].authority).toBe("ANALYSIS_ONLY");
  });

  it("executes temporal comparison as manifestation-level change without causation claims", () => {
    const a = dataset("A", "a.geojson", [feature("1", -66, { date: "2026-01-01" })]);
    const b = dataset("B", "b.geojson", [feature("1", -65, { date: "2026-02-01" })], "COMPARISON");
    const manifest = buildUploadManifest([{ name: "a.geojson", size: 1, declaredCrs: "EPSG:4326" }, { name: "b.geojson", size: 1, declaredCrs: "EPSG:4326" }]);
    const out: any = executeSpatialAnalysisGraph({ presetId: "TEMPORAL", manifest, datasets: [a.value, b.value], temporal: { leftDate: "2026-01-01", rightDate: "2026-02-01" } });
    expect(out.output.interpretation).toBe("MANIFESTATION_LEVEL_CHANGE_NOT_CAUSATION");
    expect(out.output.difference.changed).toEqual(["1"]);
  });

  it("emits the same deterministic receipt for the same graph inputs", () => {
    const a = dataset("A", "a.geojson", [feature("1", -66)]);
    const first = executeSpatialAnalysisGraph({ presetId: "INSPECT", manifest: a.manifest, datasets: [a.value] });
    const second = executeSpatialAnalysisGraph({ presetId: "INSPECT", manifest: a.manifest, datasets: [a.value] });
    expect(first.receipt.deterministicId).toBe(second.receipt.deterministicId);
  });

  it("preserves dataset state and role instead of mutating provenance during execution", () => {
    const a = dataset("A", "a.geojson", [feature("1", -66)], "PRIMARY");
    const before = JSON.stringify(a.value);
    executeSpatialAnalysisGraph({ presetId: "INSPECT", manifest: a.manifest, datasets: [a.value] });
    expect(JSON.stringify(a.value)).toBe(before);
  });
});
